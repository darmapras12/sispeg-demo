<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::table('pegawais', function (Blueprint $table) {
        // Menambahkan kolom catatan_status setelah kolom status (opsional)
        $table->text('catatan_status')->nullable()->after('status');
    });
}

public function down(): void
{
    Schema::table('pegawais', function (Blueprint $table) {
        $table->dropColumn('catatan_status');
    });
    }
};
